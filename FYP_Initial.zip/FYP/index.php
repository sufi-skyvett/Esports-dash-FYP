<?php
    require "header.php";
?>

    <main role="main" class="inner cover">
        <h1 class="cover-heading">Esports-Dash: Event Management System</h1>
        <p class="lead">A Progressive Web Application that consist of dashboard for Esports event and push notification for the system subscriber. Administrator will be able to send a notification during an event to subscriber!
        </p>
        <!--<p class="lead">-->
          <!--<a href="#" class="btn btn-lg btn-secondary">Learn more</a>
        </p>-->
        
      </main>
    
    
<?php
    require "footer.php";
?>