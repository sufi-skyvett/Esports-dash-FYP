<?php
header('Location: participant-sub-menu.php');
?>