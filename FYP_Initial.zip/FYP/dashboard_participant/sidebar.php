<div class="sidebar" data-color="blue" data-image="../light-bootstrap-assets/img/sidebar-5.jpg">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="" class="simple-text">Esports-Dash</a>
        </div>
    
        <ul class="nav">
            <li>
                <a href="participant-sub-menu.php">
                    <i class="pe-7s-user"></i>
                    <p>Main Tab</p>
                </a>
            </li>
            <li>
                <a href="participant-usage.php">
                    <i class="pe-7s-notebook"></i>
                    <p>Usage Report Tab</p>
                </a>
            </li>
            <li>
                <a href="participant-group.php">
                    <i class="pe-7s-notebook"></i>
                    <p>Group Tab</p>
                </a>
            </li>
           
        </ul>
    </div>
</div>