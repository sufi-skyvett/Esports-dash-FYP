<?php
include '../connect.php';
if(!isset($_SESSION['type']) || $_SESSION['type'] != 0 ){
    
    echo '<script>alert("Unauthorized access") </script>';
    echo '<script>window.location.href = "../logout.php" </script>';
}

$username = $_SESSION['username'];

$query = "SELECT * FROM usage_report";
$result = $conn->query($query);

if (isset($_POST['addusage-btn'])) {
    
    $id = $_POST['id'];
    $user = $_POST['user'];
    $venue = $_POST['venue'];
    $usageDate = $_POST['usageDate'];
    $activityInfo = $_POST['activityInfo'];
   
    
    $sql_checkusage = "SELECT * FROM usage_report WHERE id='$id'";
    $result_checkusage = $conn->query($sql_checkusage);
    if ($result_checkusage->num_rows > 0) {
        echo "<script>alert('Usage with id: ".$id." already exist!');</script>";
    }
    else {
        $sql_addusage = "INSERT INTO usage_report (id, user, venue, usageDate, activityInfo) VALUES ('$id','$user','$venue','$usageDate','$activityInfo')";
        if ($conn->query($sql_addusage))
        {
            echo "<script>alert('Successfully added a new usage: ".$user."!');</script>";
        } 
        else {
            echo '<script>alert("Error adding new usage!");</script>';
        }
    }
    echo '<script>window.location.href = "admin-usage.php"</script>';
}


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="../light-bootstrap-assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Esports-Dash Manager</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../light-bootstrap-assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../light-bootstrap-assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="../light-bootstrap-assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../light-bootstrap-assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../light-bootstrap-assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
</head>
<body>

    <div class="wrapper">

        <!-- Side Bar -->
        <?php include 'sidebar.php'; ?>
        
        <div class="main-panel">

            <!-- Navigation Bar -->
            <?php include 'navigationbar.php'; ?>
        
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header">
                                    <h4 class="title">Add Usage</h4>
                                </div>
                                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="id" class="col-form-label">ID:</label>
                            <input type="text" class="form-control" id="id" required name="id">
                        </div>
                       
                        <div class="form-group">
                            <label for="user" class="col-form-label">User:</label>
                            <input type="text" class="form-control" id="user" required name="user">
                        </div>
                        <div class="form-group">
                            <label for="venue" class="col-form-label">Venue:</label>
                            <input type="text" class="form-control" id="venue" required name="venue">
                        </div>
                        <div class="form-group">
                            <label for="usageDate" class="col-form-label">Date:</label>
                            <input type="text" class="form-control" id="usageDate" required name="usageDate">
                        </div>
                        <div class="form-group">
                            <label for="activityInfo" class="col-form-label">Activity:</label>
                            <input type="text" class="form-control" id="activityInfo" required name="activityInfo">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-secondary btn-fill" href="admin-usage.php">Close</a>
                        <input type="submit" class="btn btn-success btn-fill" value="Add Usage" name="addusage-btn">
                    </div>
                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include '../footer.php'; ?>
        </div>
    </div>
    
   
    
    <!--   Core JS Files   -->
    <script src="../light-bootstrap-assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
    <script src="../light-bootstrap-assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Charts Plugin -->
    <script src="../light-bootstrap-assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../light-bootstrap-assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="../light-bootstrap-assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="../light-bootstrap-assets/js/demo.js"></script>
    
    
</body>
</html>