<div class="sidebar" data-color="blue" data-image="../light-bootstrap-assets/img/sidebar-5.jpg">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="admin-participant.php" class="simple-text">Esports-Dash</a>
        </div>
    
        <ul class="nav">
            <li>
                <a href="admin-participant.php">
                    <i class="pe-7s-user"></i>
                    <p>Participant Tab</p>
                </a>
            </li>
            <li>
                <a href="admin-event.php">
                    <i class="pe-7s-notebook"></i>
                    <p>Event Tab</p>
                </a>
            </li>
            <li>
                <a href="admin-venue.php">
                    <i class="pe-7s-notebook"></i>
                    <p>Venue Tab</p>
                </a>
            </li>
            <li>
                <a href="admin-group.php">
                    <i class="pe-7s-display2"></i>
                    <p>Group Tab</p>
                </a>
            </li>
            <li>
                <a href="admin-usage.php">
                    <i class="pe-7s-news-paper"></i>
                    <p>Usage Tab</p>
                </a>
            </li>
            <li>
                <a href="admin-push.php">
                    <i class="pe-7s-news-paper"></i>
                    <p>Push notification</p>
                </a>
            </li>
        </ul>
    </div>
</div>