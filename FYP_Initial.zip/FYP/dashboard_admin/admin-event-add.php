<?php
include '../connect.php';
if(!isset($_SESSION['type']) || $_SESSION['type'] != 0 ){
    
    echo '<script>alert("Unauthorized access") </script>';
    echo '<script>window.location.href = "../logout.php" </script>';
}

$username = $_SESSION['username'];

$query = "SELECT * FROM event";
$result = $conn->query($query);

if (isset($_POST['addevent-btn'])) {
    
    $e_name = $_POST['e_name'];
    $e_details = $_POST['e_details'];
    $e_info = $_POST['e_info'];
   
    
    $sql_checkevent = "SELECT * FROM event WHERE e_name='$e_name'";
    $result_checkevent = $conn->query($sql_checkevent);
    if ($result_checkevent->num_rows > 0) {
        echo "<script>alert('Event with name: ".$e_name." already exist!');</script>";
    }
    else {
        $sql_addevent = "INSERT INTO event (e_name,e_details,e_info) VALUES ('$e_name','$e_details','$e_info')";
        if ($conn->query($sql_addevent))
        {
            echo "<script>alert('Successfully added a new event: ".$e_name."!');</script>";
        } 
        else {
            echo '<script>alert("Error adding new event!");</script>';
        }
    }
    echo '<script>window.location.href = "admin-event.php"</script>';
}


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="../light-bootstrap-assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Esports-Dash Manager</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../light-bootstrap-assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../light-bootstrap-assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="../light-bootstrap-assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../light-bootstrap-assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../light-bootstrap-assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
</head>
<body>

    <div class="wrapper">

        <!-- Side Bar -->
        <?php include 'sidebar.php'; ?>
        
        <div class="main-panel">

            <!-- Navigation Bar -->
            <?php include 'navigationbar.php'; ?>
        
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header">
                                    <h4 class="title">Add Event</h4>
                                </div>
                                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="e_name" class="col-form-label">Event name:</label>
                            <input type="text" class="form-control" id="e_name" required name="e_name">
                        </div>
                       
                        <div class="form-group">
                            <label for="e_details" class="col-form-label">Details:</label>
                            <input type="text" class="form-control" id="e_details" required name="e_details">
                        </div>
                        <div class="form-group">
                            <label for="e_info" class="col-form-label">Info:</label>
                            <input type="text" class="form-control" id="e_info" required name="e_info">
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-secondary btn-fill" href="admin-event.php">Close</a>
                        <input type="submit" class="btn btn-success btn-fill" value="Add Event" name="addevent-btn">
                    </div>
                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include '../footer.php'; ?>
        </div>
    </div>
    
   
    
    <!--   Core JS Files   -->
    <script src="../light-bootstrap-assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
    <script src="../light-bootstrap-assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Charts Plugin -->
    <script src="../light-bootstrap-assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../light-bootstrap-assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="../light-bootstrap-assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="../light-bootstrap-assets/js/demo.js"></script>
    
    
</body>
</html>