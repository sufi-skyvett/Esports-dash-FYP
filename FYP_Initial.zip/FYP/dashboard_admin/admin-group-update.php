<?php
include '../connect.php';
if(!isset($_SESSION['type']) || $_SESSION['type'] != 0 ){
    
    echo '<script>alert("Unauthorized access") </script>';
    echo '<script>window.location.href = "../logout.php" </script>';
}

$username = $_SESSION['username'];
$a=mysqli_query($conn,"SELECT * FROM group_p WHERE g_name='$_GET[g_name]'");
$b=mysqli_fetch_array($a,MYSQLI_ASSOC)



?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="../light-bootstrap-assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Esports-Dash Manager</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <!-- Bootstrap core CSS     -->
    <link href="../light-bootstrap-assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../light-bootstrap-assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="../light-bootstrap-assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../light-bootstrap-assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="../light-bootstrap-assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
</head>
<body>

    <div class="wrapper">

        <!-- Side Bar -->
        <?php include 'sidebar.php'; ?>
        
        <div class="main-panel">

            <!-- Navigation Bar -->
            <?php include 'navigationbar.php'; ?>
        
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header">
                                    <h4 class="title">Edit Group</h4>
                                </div>
                                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="g_name" class="col-form-label">Group name:</label>
                            <input type="text" class="form-control" required name="g_name" value="<?= $b['g_name']; ?>" readonly>
                        </div>
                        
                        <div class="form-group">
                            <label for="g_player" class="col-form-label">Player name:</label>
                            <input type="text" class="form-control" required name="g_player" value="<?= $b['g_player']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="g_result" class="col-form-label">Result:</label>
                            <input type="text" class="form-control" required name="g_result" value="<?= $b['g_result']; ?>">
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-secondary btn-fill" href="admin-group.php">Close</a>
                        <input class="btn btn-secondary btn-fill" type="reset" name="cancel" value="Cancel">
                        <input type="submit" class="btn btn-success btn-fill" value="Update" name="update">
                    </div>
                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include '../footer.php'; ?>
        </div>
    </div>
    
   
    
    <!--   Core JS Files   -->
    <script src="../light-bootstrap-assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
    <script src="../light-bootstrap-assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Charts Plugin -->
    <script src="../light-bootstrap-assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../light-bootstrap-assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="../light-bootstrap-assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="../light-bootstrap-assets/js/demo.js"></script>
    <?php
    if(isset($_POST['update']))
{
  include '../connect.php';
  $g_name = $_POST['g_name'];
  $g_player = $_POST['g_player'];
  $g_result = $_POST['g_result'];

  $sql="UPDATE group_p SET g_name='$g_name',g_player='$g_player',g_result='$g_result' WHERE g_name='$_GET[g_name]'";
  if($conn->query($sql) === false)
  { // Jika gagal meng-insert data tampilkan pesan dibawah 'Perintah SQL Salah'
    trigger_error('Wrong SQL Command: ' . $sql . ' Error: ' . $conn->error, E_USER_ERROR);
  }  
  else 
  { // Jika berhasil alihkan ke halaman tampil.php
    echo "<script>alert('Update Success!')</script>";
  	echo "<meta http-equiv=refresh content=\"0; url=admin-group.php\">";
  }
}
?>


    
</body>
</html>