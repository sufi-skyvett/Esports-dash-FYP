<?php
if (!isset($_SESSION)) {
  session_start();
}

// Connect to database
$conn = mysqli_connect("localhost", "u203663259_esportsdashfyp", "Skyvett2020", "u203663259_esportsdash");
global $conn;

if (!$conn) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
?>
